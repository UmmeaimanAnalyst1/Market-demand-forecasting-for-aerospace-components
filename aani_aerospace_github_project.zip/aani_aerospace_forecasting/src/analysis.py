"""
AANI Aerospace - Landing Gear Sales Demand Forecasting
MBA Internship Project | 2024-2025

Models: ARIMA (1,1,1) + Random Forest
Data: Monthly Landing Gear Sales & Defects (Jan 2024 - Jun 2025)
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import warnings
warnings.filterwarnings("ignore")

from statsmodels.tsa.arima.model import ARIMA
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, mean_absolute_percentage_error
import os

# ─────────────────────────────────────────────
# 1. LOAD & PREPARE DATA
# ─────────────────────────────────────────────

def load_data():
    sales = pd.read_excel("data/sales_data.xlsx")
    defects = pd.read_excel("data/defects_data.xlsx")

    # Parse dates (already converted by openpyxl)
    for df in [sales, defects]:
        df['Date'] = pd.to_datetime(df['Date'], errors='coerce')

    # Monthly aggregation
    sales_monthly = (
        sales.groupby(pd.Grouper(key='Date', freq='MS'))['Units Sold']
        .sum()
        .reset_index()
        .rename(columns={'Units Sold': 'Sales'})
    )

    defects_monthly = (
        defects.groupby(pd.Grouper(key='Date', freq='MS'))['Defected Units']
        .sum()
        .reset_index()
        .rename(columns={'Defected Units': 'Defects'})
    )

    merged = pd.merge(sales_monthly, defects_monthly, on='Date', how='left').fillna(0)
    merged['Defects'] = merged['Defects'].astype(int)

    print("✅ Data loaded:")
    print(merged.to_string(index=False))
    return sales, defects, merged


def client_breakdown(sales):
    print("\n📊 Sales by Client:")
    print(sales.groupby('Client')['Units Sold'].sum().sort_values(ascending=False).to_string())

    print("\n📦 Sales by Product Line:")
    print(sales.groupby('Product Line')['Units Sold'].sum().to_string())


# ─────────────────────────────────────────────
# 2. VISUALIZE HISTORICAL TREND
# ─────────────────────────────────────────────

def plot_historical(merged):
    fig, axes = plt.subplots(2, 1, figsize=(12, 8))

    ax1 = axes[0]
    ax1.plot(merged['Date'], merged['Sales'], marker='o', color='#1f77b4', linewidth=2, markersize=6)
    ax1.fill_between(merged['Date'], merged['Sales'], alpha=0.15, color='#1f77b4')
    ax1.set_title('Historical Monthly Sales Trend – Landing Gear Components (2024–2025)', fontsize=13, fontweight='bold')
    ax1.set_ylabel('Units Sold')
    ax1.xaxis.set_major_formatter(mdates.DateFormatter('%b %Y'))
    ax1.grid(True, alpha=0.3)
    plt.setp(ax1.xaxis.get_majorticklabels(), rotation=45)

    ax2 = axes[1]
    ax2.bar(merged['Date'], merged['Defects'], color='#d62728', alpha=0.75, width=20)
    ax2.set_title('Monthly Defects Count', fontsize=13, fontweight='bold')
    ax2.set_ylabel('Defected Units')
    ax2.xaxis.set_major_formatter(mdates.DateFormatter('%b %Y'))
    ax2.grid(True, alpha=0.3, axis='y')
    plt.setp(ax2.xaxis.get_majorticklabels(), rotation=45)

    plt.tight_layout()
    os.makedirs("outputs", exist_ok=True)
    plt.savefig("outputs/01_historical_trend.png", dpi=150, bbox_inches='tight')
    plt.close()
    print("✅ Saved: outputs/01_historical_trend.png")


# ─────────────────────────────────────────────
# 3. ARIMA MODEL
# ─────────────────────────────────────────────

def run_arima(merged):
    series = merged.set_index('Date')['Sales'].asfreq('MS')
    train = series.iloc[:-6]
    test = series.iloc[-6:]

    model = ARIMA(train, order=(1, 1, 1))
    fit = model.fit()
    forecast_test = fit.forecast(steps=6)

    rmse = np.sqrt(mean_squared_error(test, forecast_test))
    mape = mean_absolute_percentage_error(test, forecast_test) * 100

    print(f"\n📈 ARIMA (1,1,1) Results:")
    print(f"   RMSE : {rmse:.2f}")
    print(f"   MAPE : {mape:.2f}%")

    # 12-month forecast
    full_model = ARIMA(series, order=(1, 1, 1)).fit()
    forecast_12 = full_model.forecast(steps=12)
    future_dates = pd.date_range(start=series.index[-1] + pd.DateOffset(months=1), periods=12, freq='MS')

    return {
        'test': test,
        'forecast_test': forecast_test,
        'forecast_12': forecast_12,
        'future_dates': future_dates,
        'rmse': rmse,
        'mape': mape
    }


# ─────────────────────────────────────────────
# 4. RANDOM FOREST MODEL
# ─────────────────────────────────────────────

def run_random_forest(merged):
    df = merged.copy()
    df['Lag1'] = df['Sales'].shift(1)
    df['Lag2'] = df['Sales'].shift(2)
    df['RollingMean3'] = df['Sales'].rolling(3).mean()
    df = df.dropna()

    X = df[['Lag1', 'Lag2', 'RollingMean3', 'Defects']]
    y = df['Sales']

    X_train, X_test = X.iloc[:-6], X.iloc[-6:]
    y_train, y_test = y.iloc[:-6], y.iloc[-6:]

    rf = RandomForestRegressor(n_estimators=200, random_state=42, max_depth=5)
    rf.fit(X_train, y_train)
    y_pred = rf.predict(X_test)

    rmse = np.sqrt(mean_squared_error(y_test, y_pred))
    mape = mean_absolute_percentage_error(y_test, y_pred) * 100

    print(f"\n🌲 Random Forest Results:")
    print(f"   RMSE : {rmse:.2f}")
    print(f"   MAPE : {mape:.2f}%")

    # Iterative 12-month forecast
    last_vals = list(df['Sales'].values[-3:])
    future_preds = []
    for _ in range(12):
        lag1 = last_vals[-1]
        lag2 = last_vals[-2]
        rolling = np.mean(last_vals[-3:])
        pred = rf.predict([[lag1, lag2, rolling, 1]])[0]
        future_preds.append(pred)
        last_vals.append(pred)

    future_dates = pd.date_range(
        start=merged['Date'].iloc[-1] + pd.DateOffset(months=1), periods=12, freq='MS'
    )

    return {
        'test': y_test,
        'forecast_test': y_pred,
        'forecast_12': future_preds,
        'future_dates': future_dates,
        'rmse': rmse,
        'mape': mape
    }


# ─────────────────────────────────────────────
# 5. COMPARISON PLOT
# ─────────────────────────────────────────────

def plot_model_comparison(merged, arima_res, rf_res):
    test_dates = merged['Date'].iloc[-6:]

    fig, axes = plt.subplots(1, 2, figsize=(16, 5))

    # --- Test period comparison ---
    ax = axes[0]
    ax.plot(test_dates, arima_res['test'].values, label='Actual', marker='o', linewidth=2, color='black')
    ax.plot(test_dates, arima_res['forecast_test'].values, label='ARIMA', marker='s', linestyle='--', color='#2ca02c')
    ax.plot(test_dates, rf_res['forecast_test'], label='Random Forest', marker='^', linestyle='--', color='#d62728')
    ax.set_title('Model Comparison – Test Period (Last 6 Months)', fontweight='bold')
    ax.set_ylabel('Units Sold')
    ax.legend()
    ax.grid(True, alpha=0.3)
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%b %Y'))
    plt.setp(ax.xaxis.get_majorticklabels(), rotation=45)

    # --- 12-Month forecast ---
    ax2 = axes[1]
    hist_dates = merged['Date']
    hist_sales = merged['Sales']
    ax2.plot(hist_dates, hist_sales, label='Historical', color='black', linewidth=1.5)
    ax2.plot(arima_res['future_dates'], arima_res['forecast_12'], label='ARIMA Forecast', marker='s',
             linestyle='--', color='#2ca02c', linewidth=2)
    ax2.plot(rf_res['future_dates'], rf_res['forecast_12'], label='RF Forecast', marker='^',
             linestyle='--', color='#d62728', linewidth=2)
    ax2.axvline(x=merged['Date'].iloc[-1], color='gray', linestyle=':', linewidth=1.5, label='Forecast Start')
    ax2.set_title('12-Month Demand Forecast (Jul 2025 – Jun 2026)', fontweight='bold')
    ax2.set_ylabel('Units Sold')
    ax2.legend()
    ax2.grid(True, alpha=0.3)
    ax2.xaxis.set_major_formatter(mdates.DateFormatter('%b %Y'))
    plt.setp(ax2.xaxis.get_majorticklabels(), rotation=45)

    plt.tight_layout()
    plt.savefig("outputs/02_model_comparison_and_forecast.png", dpi=150, bbox_inches='tight')
    plt.close()
    print("✅ Saved: outputs/02_model_comparison_and_forecast.png")


# ─────────────────────────────────────────────
# 6. DEFECTS VS SALES CORRELATION
# ─────────────────────────────────────────────

def plot_defects_correlation(merged):
    corr = merged['Sales'].corr(merged['Defects'])
    print(f"\n🔗 Defects vs Sales Correlation: {corr:.4f}")

    fig, axes = plt.subplots(1, 2, figsize=(14, 5))

    ax1 = axes[0]
    ax1.scatter(merged['Defects'], merged['Sales'], color='#9467bd', s=80, alpha=0.7, edgecolors='black')
    z = np.polyfit(merged['Defects'], merged['Sales'], 1)
    p = np.poly1d(z)
    xline = np.linspace(merged['Defects'].min(), merged['Defects'].max(), 100)
    ax1.plot(xline, p(xline), "r--", linewidth=1.5, label=f'Trend (r={corr:.2f})')
    ax1.set_title('Defects vs Sales Correlation', fontweight='bold')
    ax1.set_xlabel('Defected Units')
    ax1.set_ylabel('Units Sold')
    ax1.legend()
    ax1.grid(True, alpha=0.3)

    ax2 = axes[1]
    colors = ['#d62728' if d > 0 else '#2ca02c' for d in merged['Defects']]
    bars = ax2.bar(merged['Date'], merged['Sales'], color=colors, alpha=0.8, width=20)
    ax2.set_title('Monthly Sales (Red = Months with Defects)', fontweight='bold')
    ax2.set_ylabel('Units Sold')
    ax2.xaxis.set_major_formatter(mdates.DateFormatter('%b %Y'))
    plt.setp(ax2.xaxis.get_majorticklabels(), rotation=45)
    ax2.grid(True, alpha=0.3, axis='y')

    plt.tight_layout()
    plt.savefig("outputs/03_defects_correlation.png", dpi=150, bbox_inches='tight')
    plt.close()
    print("✅ Saved: outputs/03_defects_correlation.png")


# ─────────────────────────────────────────────
# 7. SUMMARY TABLE + FORECAST EXPORT
# ─────────────────────────────────────────────

def export_forecast(arima_res, rf_res):
    df_out = pd.DataFrame({
        'Month': arima_res['future_dates'].strftime('%Y-%m'),
        'ARIMA_Forecast': arima_res['forecast_12'].values.round(1),
        'RF_Forecast': np.round(rf_res['forecast_12'], 1)
    })
    df_out.to_csv("outputs/forecast_12months.csv", index=False)
    print("\n✅ Saved: outputs/forecast_12months.csv")
    print(df_out.to_string(index=False))

    summary = pd.DataFrame({
        'Model': ['ARIMA (1,1,1)', 'Random Forest'],
        'RMSE': [round(arima_res['rmse'], 2), round(rf_res['rmse'], 2)],
        'MAPE (%)': [round(arima_res['mape'], 2), round(rf_res['mape'], 2)]
    })
    summary.to_csv("outputs/model_performance.csv", index=False)
    print("\n📊 Model Performance Summary:")
    print(summary.to_string(index=False))


# ─────────────────────────────────────────────
# 8. MAIN
# ─────────────────────────────────────────────

if __name__ == "__main__":
    print("=" * 55)
    print("  AANI Aerospace – Demand Forecasting Analysis")
    print("=" * 55)

    sales, defects, merged = load_data()
    client_breakdown(sales)

    plot_historical(merged)

    arima_res = run_arima(merged)
    rf_res = run_random_forest(merged)

    plot_model_comparison(merged, arima_res, rf_res)
    plot_defects_correlation(merged)
    export_forecast(arima_res, rf_res)

    print("\n✅ All done! Check the outputs/ folder.")
