# 🚀 GitHub Upload – Step-by-Step Guide
## AANI Aerospace Forecasting Project

---

## STEP 1 — Create a GitHub Account (if you don't have one)
1. Go to https://github.com
2. Click **Sign up**
3. Enter your email, create a password, choose a username
4. Verify your email

---

## STEP 2 — Create a New Repository on GitHub

1. Log in to GitHub
2. Click the **"+"** button (top right) → **"New repository"**
3. Fill in:
   - **Repository name:** `aani_aerospace_forecasting`
   - **Description:** `MBA Internship – Landing Gear Demand Forecasting using ARIMA & Random Forest | AANI Aerospace`
   - **Visibility:** Public (or Private)
   - ✅ Check **"Add a README file"** — NO (we already have one)
   - Leave everything else default
4. Click **"Create repository"**

---

## STEP 3 — Install Git on Your Computer

### Windows:
1. Download from: https://git-scm.com/download/win
2. Run the installer (click Next → Next → Install)
3. Open **Git Bash** from Start Menu

### Mac:
```bash
xcode-select --install
```

### Linux (Ubuntu):
```bash
sudo apt install git
```

---

## STEP 4 — Configure Git (One-time Setup)

Open Terminal / Git Bash and run:
```bash
git config --global user.name "Your Name"
git config --global user.email "your-email@example.com"
```

Replace with your actual name and GitHub email.

---

## STEP 5 — Set Up the Project Folder

On your computer, create this folder structure and place your files:

```
aani_aerospace_forecasting/
├── data/
│   ├── sales_data.xlsx
│   └── defects_data.xlsx
├── src/
│   └── analysis.py
├── notebooks/
│   └── AANI_Forecasting.ipynb
├── outputs/              (this folder will be created when you run the script)
├── docs/
│   └── internship_report.pdf
├── .gitignore
├── requirements.txt
└── README.md
```

---

## STEP 6 — Initialize Git and Push to GitHub

Open Terminal in your project folder and run these commands **one by one**:

```bash
# 1. Go inside your project folder
cd path/to/aani_aerospace_forecasting

# 2. Initialize git
git init

# 3. Add all files
git add .

# 4. Make your first commit
git commit -m "Initial commit - AANI Aerospace demand forecasting project"

# 5. Connect to your GitHub repo (replace YOUR_USERNAME)
git remote add origin https://github.com/YOUR_USERNAME/aani_aerospace_forecasting.git

# 6. Push to GitHub
git branch -M main
git push -u origin main
```

GitHub will ask for your **username** and **password** (use a Personal Access Token — see Step 7).

---

## STEP 7 — Create a Personal Access Token (Required for Password)

GitHub no longer accepts your regular password. Use a token instead:

1. Go to GitHub → click your profile photo (top right) → **Settings**
2. Scroll down → **Developer settings** (left sidebar)
3. Click **Personal access tokens** → **Tokens (classic)**
4. Click **Generate new token (classic)**
5. Set:
   - Note: `git push token`
   - Expiration: 90 days
   - Scopes: ✅ **repo** (check this one)
6. Click **Generate token**
7. **Copy the token** — you only see it once!

When Git asks for your password, **paste this token** instead.

---

## STEP 8 — Run the Analysis (Generate Output Files)

Before pushing, run the script to generate charts and CSV files:

```bash
# Install dependencies
pip install -r requirements.txt

# Run the analysis
python src/analysis.py
```

Then add the output files too:
```bash
git add outputs/
git commit -m "Add analysis outputs - charts and forecast CSVs"
git push
```

---

## STEP 9 — Verify on GitHub

1. Go to https://github.com/YOUR_USERNAME/aani_aerospace_forecasting
2. You should see all your files
3. The README will display beautifully on the main page

---

## ✅ Quick Reference — Common Git Commands

| Command | What it does |
|---------|-------------|
| `git status` | See what files changed |
| `git add .` | Stage all changes |
| `git add filename` | Stage one file |
| `git commit -m "message"` | Save a snapshot |
| `git push` | Upload to GitHub |
| `git pull` | Download latest from GitHub |
| `git log` | See commit history |

---

## 🛠️ Troubleshooting

**Problem:** `git push` asks for username/password repeatedly
**Fix:** Use token (Step 7) or set up SSH keys

**Problem:** `error: remote origin already exists`
**Fix:** Run `git remote remove origin` then add it again

**Problem:** Permission denied
**Fix:** Make sure you're using the correct GitHub username and token

**Problem:** Files too large (>100MB)
**Fix:** Add them to `.gitignore` or use Git LFS

---

## 📌 Your Repository URL (after setup)
```
https://github.com/YOUR_USERNAME/aani_aerospace_forecasting
```

Share this link in your internship report! ✈️
