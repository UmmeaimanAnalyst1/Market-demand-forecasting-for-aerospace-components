# ✈️ AANI Aerospace – Landing Gear Sales Demand Forecasting

**MBA Internship Project | AANI Aerospace Pvt. Ltd., Belagavi, Karnataka**

> Forecasting market demand for Airbus A320neo landing gear components using ARIMA and Random Forest models — based on 18 months of real sales & defect data (Jan 2024 – Jun 2025).

---

## 📌 Project Overview

| Item | Detail |
|------|--------|
| **Company** | AANI Aerospace Manufacturing Pvt. Ltd. |
| **Location** | Belagavi, Karnataka, India |
| **Products** | Main Landing Gear, Nose Landing Gear |
| **Clients** | DRDO, ISRO, HAL, Airbus India, Boeing India |
| **Data Period** | January 2024 – June 2025 (18 months) |
| **Forecast Horizon** | 12 months (July 2025 – June 2026) |

---

## 📊 Key Results

| Model | RMSE | MAPE |
|-------|------|------|
| ARIMA (1,1,1) | 6.77 | 28.23% |
| Random Forest | 10.20 | 37.94% |

- **ARIMA** outperformed Random Forest on this short dataset
- Defects vs Sales correlation: **r = 0.49** (moderate positive — market demand drives sales more than quality issues)
- 12-month forecast shows **stable demand ~25–35 units/month**

---

## 🗂️ Project Structure

```
aani_aerospace_forecasting/
│
├── data/
│   ├── sales_data.xlsx              # Monthly landing gear sales (2024-2025)
│   └── defects_data.xlsx            # Sales with defect tracking
│
├── src/
│   └── analysis.py                  # Main analysis script (ARIMA + RF)
│
├── notebooks/
│   └── AANI_Forecasting.ipynb       # Jupyter notebook version
│
├── outputs/
│   ├── 01_historical_trend.png      # Historical sales + defects chart
│   ├── 02_model_comparison_and_forecast.png   # Model test + 12M forecast
│   ├── 03_defects_correlation.png   # Defects vs Sales analysis
│   ├── forecast_12months.csv        # 12-month forecast table
│   └── model_performance.csv        # RMSE & MAPE comparison
│
├── docs/
│   └── internship_report.pdf        # Full MBA internship report
│
├── requirements.txt
└── README.md
```

---

## ⚙️ How to Run

### 1. Clone the Repository
```bash
git clone https://github.com/YOUR_USERNAME/aani_aerospace_forecasting.git
cd aani_aerospace_forecasting
```

### 2. Install Dependencies
```bash
pip install -r requirements.txt
```

### 3. Run the Analysis
```bash
python src/analysis.py
```

### 4. Or Open the Notebook
```bash
jupyter notebook notebooks/AANI_Forecasting.ipynb
```

All charts and forecast CSVs will be saved in `outputs/`.

---

## 📈 Data Summary

**Sales by Client (Total Units)**

| Client | Units Sold |
|--------|-----------|
| DRDO | 133 |
| ISRO | 99 |
| HAL | 82 |
| Airbus India | 75 |
| Boeing India | 71 |
| **Total** | **460** |

**Sales by Product Line**

| Product | Units |
|---------|-------|
| Main Landing Gear | 246 |
| Nose Landing Gear | 214 |

---

## 🔍 Methodology

1. **Data Collection** – Historical sales & defect records (Excel)
2. **Preprocessing** – Date parsing, monthly aggregation, feature engineering
3. **ARIMA Model** – Time series forecasting with order (1,1,1)
4. **Random Forest** – Lag features (Lag1, Lag2, Rolling Mean) + Defects
5. **Evaluation** – Train/test split (last 6 months as test), RMSE & MAPE
6. **12-Month Forecast** – Iterative prediction for Jul 2025 – Jun 2026

---

## 💡 Key Findings

- Sales are **highly volatile** month-to-month (range: 5–51 units)
- **No strong seasonal pattern** due to short data window
- Defects are **low** (0–2/month) and weakly correlated with sales volume
- External market factors (client procurement cycles, defense budgets) drive demand more than product quality
- ARIMA achieves ~28% MAPE — reasonable for aerospace component forecasting

---

## 📚 Tools & Libraries

- Python 3.10+
- `pandas`, `numpy` – data processing
- `statsmodels` – ARIMA model
- `scikit-learn` – Random Forest
- `matplotlib` – visualizations
- `openpyxl` – Excel reading

---

## 👤 Author

**Umme Ayeman**  
MBA Intern | AANI Aerospace Pvt. Ltd.  
Belagavi, Karnataka | 2024–2025

---

## 📄 License

This project is for academic/internship purposes only. Data belongs to AANI Aerospace Pvt. Ltd.
